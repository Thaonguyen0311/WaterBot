// ESP32 Robot Control (PlatformIO / Arduino)
// Mit 10-facher Mittelwertbildung für die Analog-Sensoren

#include <Arduino.h>
#include <NewPing.h>

// ---------------- Pins ----------------
static const int PIN_A_RIGHT = 34;
static const int PIN_A_LEFT  = 35;

static const int PIN_BTN_STOP  = 32;
static const int PIN_BTN_START = 33;

static const int PIN_TRIG = 25;
static const int PIN_ECHO = 26;

static const int PIN_LED_RED   = 2;
static const int PIN_LED_GREEN = 4;
static const int PIN_LED_BLUE  = 5;

static const int PIN_MR_1 = 27;
static const int PIN_MR_2 = 14;

static const int PIN_ML_1 = 19;
static const int PIN_ML_2 = 18;

// -------------- Ultraschall -----------
static const unsigned int US_MAX_CM = 400;
NewPing sonar(PIN_TRIG, PIN_ECHO, US_MAX_CM);

// -------------- PWM Setup -------------
static const uint32_t PWM_FREQ = 30000; 
static const uint8_t  PWM_RES  = 8;      
static const uint32_t PWM_MAX  = (1UL << PWM_RES) - 1; 

static const int CH_MR_1 = 0;
static const int CH_MR_2 = 1;
static const int CH_ML_1 = 2;
static const int CH_ML_2 = 3;

// ----------- User Variablen -----------
volatile int dutycycle_turn = 100;  
volatile int tollaranz      = 200;  

volatile int dutycycle_run  = 15;  
volatile int obstacle_cm    = 20;  

// ---------- Mittelwertbildung ---------
const int numReadings = 10;
int readingsRight[numReadings]; 
int readingsLeft[numReadings];  
int readIndex = 0;              
long totalRight = 0;            
long totalLeft = 0;             

// -------------- State -----------------
enum Mode { WAKE_UP, RUN, STOP };
Mode mode = WAKE_UP;
unsigned long modeEnterMs = 0;

// --------- Button Edge Detect ---------
bool lastStop = false;
bool lastStart = false;

// ---------- Helper: LEDs --------------
void setLED(bool redOn, bool greenOn, bool blueOn) {
  digitalWrite(PIN_LED_RED,   redOn   ? LOW : HIGH);
  digitalWrite(PIN_LED_GREEN, greenOn ? LOW : HIGH);
  digitalWrite(PIN_LED_BLUE,  blueOn  ? LOW : HIGH);
}

// --------- Helper: Motor PWM ----------
uint32_t percentToInvertedDuty(int percent) {
  percent = constrain(percent, 0, 100);
  return map(percent, 0, 100, PWM_MAX, 0);
}

void setRightMotorPercent(int percent) {
  uint32_t d = percentToInvertedDuty(percent);
  ledcWrite(CH_MR_1, d);
  ledcWrite(CH_MR_2, d);
}

void setLeftMotorPercent(int percent) {
  uint32_t d = percentToInvertedDuty(percent);
  ledcWrite(CH_ML_1, d);
  ledcWrite(CH_ML_2, d);
}

void motorsStop() {
  ledcWrite(CH_MR_1, 0); ledcWrite(CH_MR_2, 0);
  ledcWrite(CH_ML_1, 0); ledcWrite(CH_ML_2, 0);
  digitalWrite(PIN_MR_1, LOW); digitalWrite(PIN_MR_2, LOW);
  digitalWrite(PIN_ML_1, LOW); digitalWrite(PIN_ML_2, LOW);
}

// -------- Mode Switching --------------
void enterMode(Mode m) {
  mode = m;
  modeEnterMs = millis();
  if (mode == RUN) {
    setLED(false, true, false);
  } else {
    motorsStop();
  }
}

void stopBlinkThenSolidRed() {
  for (int i = 0; i < 3; i++) {
    setLED(true, false, false); delay(200);
    setLED(false, false, false); delay(200);
  }
  setLED(true, false, false);
}

// -------------- Setup -----------------
void setup() {
  Serial.begin(115200);

  pinMode(PIN_A_RIGHT, INPUT);
  pinMode(PIN_A_LEFT,  INPUT);
  pinMode(PIN_BTN_STOP,  INPUT_PULLDOWN);
  pinMode(PIN_BTN_START, INPUT_PULLDOWN);
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_BLUE, OUTPUT);
  setLED(false, false, false);

  ledcSetup(CH_MR_1, PWM_FREQ, PWM_RES);
  ledcSetup(CH_MR_2, PWM_FREQ, PWM_RES);
  ledcSetup(CH_ML_1, PWM_FREQ, PWM_RES);
  ledcSetup(CH_ML_2, PWM_FREQ, PWM_RES);

  ledcAttachPin(PIN_MR_1, CH_MR_1);
  ledcAttachPin(PIN_MR_2, CH_MR_2);
  ledcAttachPin(PIN_ML_1, CH_ML_1);
  ledcAttachPin(PIN_ML_2, CH_ML_2);

  // Initialisiere die Arrays für die Mittelwertbildung mit 0
  for (int i = 0; i < numReadings; i++) {
    readingsRight[i] = 0;
    readingsLeft[i] = 0;
  }

  motorsStop();
  enterMode(WAKE_UP);
}

void readButtons(bool &stopPressedEdge, bool &startPressedEdge) {
  bool s = digitalRead(PIN_BTN_STOP);
  bool t = digitalRead(PIN_BTN_START);
  stopPressedEdge  = (s && !lastStop);
  startPressedEdge = (t && !lastStart);
  lastStop = s;
  lastStart = t;
}

// -------------- RUN Logic -------------
void runLogic(bool stopEdge) {
  if (stopEdge) {
    enterMode(STOP);
    stopBlinkThenSolidRed();
    return;
  }

  unsigned int dist = sonar.ping_cm();
  if (dist > 0 && dist <= (unsigned int)obstacle_cm) {
    enterMode(STOP);
    stopBlinkThenSolidRed();
    return;
  }

  // --- MITTELWERTBILDUNG ---
  // Subtrahiere den ältesten Wert vom Total
  totalRight = totalRight - readingsRight[readIndex];
  totalLeft = totalLeft - readingsLeft[readIndex];

  // Neue Werte lesen
  readingsRight[readIndex] = analogRead(PIN_A_RIGHT);
  readingsLeft[readIndex] = analogRead(PIN_A_LEFT);

  // Addiere neuen Wert zum Total
  totalRight = totalRight + readingsRight[readIndex];
  totalLeft = totalLeft + readingsLeft[readIndex];

  // Index weiterschalten
  readIndex = (readIndex + 1) % numReadings;

  // Durchschnitt berechnen
  int avgRight = totalRight / numReadings;
  int avgLeft = totalLeft / numReadings;
  // -------------------------

  int diff = avgRight - avgLeft;
  int absdiff = abs(diff);

  int base = constrain(dutycycle_run, 0, 100);

  if (absdiff >= tollaranz) {
    setLED(false, false, true); // Blau beim Abbiegen
    if (diff > 0) {
      // Rechtskurve
      setRightMotorPercent(16);
      setLeftMotorPercent(100);
    } else {
      // Linkskurve
      setRightMotorPercent(100);
      setLeftMotorPercent(16);
    }
  } else { 
    // Geradeaus
    setLED(false, true, false);
    setRightMotorPercent(base);
    setLeftMotorPercent(base);
  }
}

void stopLogic(bool startEdge) {
  setLED(true, false, false);
  motorsStop();
  if (startEdge) enterMode(RUN);
}

void wakeUpLogic() {
  motorsStop();
  unsigned long elapsed = millis() - modeEnterMs;
  bool on = ((elapsed / 250) % 2) == 0;
  setLED(false, false, on);
  if (elapsed >= 2000) enterMode(RUN);
}

void loop() {
  bool stopEdge = false, startEdge = false;
  readButtons(stopEdge, startEdge);

  switch (mode) {
    case WAKE_UP: wakeUpLogic(); break;
    case RUN:     runLogic(stopEdge); break;
    case STOP:    stopLogic(startEdge); break;
  }

  delay(10); 
}